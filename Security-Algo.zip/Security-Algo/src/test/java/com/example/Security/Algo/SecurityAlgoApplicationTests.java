package com.example.Security.Algo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurityAlgoApplicationTests {

	@Test
	void contextLoads() {
	}

}
