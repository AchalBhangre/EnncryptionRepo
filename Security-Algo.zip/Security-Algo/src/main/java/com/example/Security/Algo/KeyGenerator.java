package com.example.Security.Algo;

import java.security.SecureRandom;
import java.util.Base64;

public class KeyGenerator {

    public static void main(String[] args) {
        byte[] keyBytes = generateRandomKey();
        String key = Base64.getEncoder().encodeToString(keyBytes);
        System.out.println("Generated Key: " + key);
    }

    public static byte[] generateRandomKey() {
        SecureRandom secureRandom = new SecureRandom();
        byte[] key = new byte[16]; // 128 bits
        secureRandom.nextBytes(key);
        return key;
    }
}

