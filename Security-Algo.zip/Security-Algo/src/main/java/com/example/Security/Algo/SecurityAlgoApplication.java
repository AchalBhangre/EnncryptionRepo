package com.example.Security.Algo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurityAlgoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecurityAlgoApplication.class, args);
	}

}
