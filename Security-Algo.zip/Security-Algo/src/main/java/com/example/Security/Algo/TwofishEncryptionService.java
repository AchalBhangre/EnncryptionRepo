package com.example.Security.Algo;

import org.bouncycastle.crypto.BufferedBlockCipher;
import org.bouncycastle.crypto.CipherParameters;
import org.bouncycastle.crypto.engines.TwofishEngine;
import org.bouncycastle.crypto.modes.CFBBlockCipher;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.crypto.params.ParametersWithIV;
import org.springframework.stereotype.Service;

@Service
public class TwofishEncryptionService {

    private byte[] key; // 16 bytes (128 bits) Twofish encryption key
    private byte[] iv;  // 16 bytes (128 bits) Initialization Vector

    public TwofishEncryptionService(byte[] key, byte[] iv) {
        this.key = key;
        this.iv = iv;
    }
    public byte[] encrypt(byte[] input) {
        BufferedBlockCipher cipher = new BufferedBlockCipher(new CFBBlockCipher(new TwofishEngine(), 128));
        CipherParameters params = new ParametersWithIV(new KeyParameter(key), iv);

        cipher.init(true, params);

        byte[] output = new byte[cipher.getOutputSize(input.length)];
        int length = cipher.processBytes(input, 0, input.length, output, 0);

        try {
            length += cipher.doFinal(output, length);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

        byte[] result = new byte[length];
        System.arraycopy(output, 0, result, 0, length);
        return result;
    }

    public byte[] decrypt(byte[] input) {
        BufferedBlockCipher cipher = new BufferedBlockCipher(new CFBBlockCipher(new TwofishEngine(), 128));
        CipherParameters params = new ParametersWithIV(new KeyParameter(key), iv);

        cipher.init(false, params);

        byte[] output = new byte[cipher.getOutputSize(input.length)];
        int length = cipher.processBytes(input, 0, input.length, output, 0);

        try {
            length += cipher.doFinal(output, length);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

        byte[] result = new byte[length];
        System.arraycopy(output, 0, result, 0, length);
        return result;
    }
}

