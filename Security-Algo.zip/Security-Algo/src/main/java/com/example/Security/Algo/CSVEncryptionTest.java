package com.example.Security.Algo;

import com.example.Security.Algo.TwofishEncryptionService;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVRecord;

import java.io.*;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

public class CSVEncryptionTest {

    public static void main(String[] args) {
        // Replace with your actual key and initialization vector (IV)
        byte[] key = "qxTfyVo65LfYl1P/VfsPsQ==".getBytes();
        byte[] iv = "wV7F7k4iSg+9Q3YaPGCZ4Q==".getBytes();

        TwofishEncryptionService encryptionService = new TwofishEncryptionService(key, iv);

        String inputCsvFilePath = "/Users/achalbhangre/Downloads/Reasearch project progess documents/IMPLEMENTATION/MRI-XRAYS/test/_annotations.csv";
        String encryptedOutputFilePath = "/Users/achalbhangre/Downloads/output/encryption/encrypted.csv"; // CSV file to save the encrypted data
        String decryptedOutputFilePath = "/Users/achalbhangre/Downloads/output/decryption/decrypted.csv"; // CSV file to save the decrypted data

        try {
            // Read CSV data
            CSVParser parser = CSVParser.parse(new File(inputCsvFilePath), Charset.defaultCharset(), CSVFormat.DEFAULT);
            // Record the start time for encryption
            long startTime = System.currentTimeMillis();
            long endTime = 0;

            List<String[]> originalData = new ArrayList<>();
            List<String[]> decryptedData = new ArrayList<>();

            for (CSVRecord record : parser) {
                String[] columns = new String[record.size()];
                String[] decryptedColumns = new String[record.size()];

                for (int i = 0; i < record.size(); i++) {
                    String originalValue = record.get(i);

                    // Encrypt the original value
                    byte[] encryptedBytes = encryptionService.encrypt(originalValue.getBytes());
                    String encryptedValue = new String(encryptedBytes);
                    columns[i] = encryptedValue;
                     endTime = System.currentTimeMillis();
                    // Decrypt the encrypted value
                    byte[] decryptedBytes = encryptionService.decrypt(encryptedBytes);
                    String decryptedValue = new String(decryptedBytes);
                    decryptedColumns[i] = decryptedValue;
                }

                originalData.add(columns);
                decryptedData.add(decryptedColumns);
            }
            // Record the end time for encryption
            // Calculate the elapsed time for encryption
            long elapsedTime = endTime - startTime;

            // Calculate the size of the dataset (in bytes)
            File inputFile = new File(inputCsvFilePath);
            long dataSize = inputFile.length();

            // Calculate encryption speed in bytes per second (Bps)
            double encryptionSpeed = dataSize / (elapsedTime / 1000.0);

            System.out.println("Encryption speed: " + encryptionSpeed + " Bps");

            // Save the encrypted data to a new CSV file
            writeCSVToFile(encryptedOutputFilePath, originalData);
            System.out.println("Encryption complete. Encrypted data saved to " + encryptedOutputFilePath);

            // Save the decrypted data to a new CSV file
            writeCSVToFile(decryptedOutputFilePath, decryptedData);
            System.out.println("Decryption complete. Decrypted data saved to " + decryptedOutputFilePath);

            if (isDataEqual(originalData, decryptedData)) {
                System.out.println("Data is identical between the original and decrypted files.");
            } else {
                System.out.println("Data is different between the original and decrypted files.");
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void writeCSVToFile(String filePath, List<String[]> data) throws IOException {
        FileWriter fileWriter = new FileWriter(filePath);
        CSVPrinter csvPrinter = new CSVPrinter(fileWriter, CSVFormat.DEFAULT);

        for (String[] row : data) {
            csvPrinter.printRecord((Object[]) row);
        }

        csvPrinter.close();
        fileWriter.close();
    }

    public static boolean isDataEqual(List<String[]> data1, List<String[]> data2) {
        if (data1.size() != data2.size()) {
            return false;
        }

        for (int i = 0; i < data1.size(); i++) {
            String[] row1 = data1.get(i);
            String[] row2 = data2.get(i);

            if (row1.length != row2.length) {
                return false;
            }

            for (int j = 0; j < row1.length; j++) {
                if (!row1[j].equals(row2[j])) {
                    return false;
                }
            }
        }

        return true;
    }
}
