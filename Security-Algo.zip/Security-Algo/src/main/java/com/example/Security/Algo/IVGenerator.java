package com.example.Security.Algo;

import java.security.SecureRandom;
import java.util.Base64;

public class IVGenerator {

    public static void main(String[] args) {
        byte[] ivBytes = generateRandomIV();
        String iv = Base64.getEncoder().encodeToString(ivBytes);
        System.out.println("Generated IV: " + iv);
    }

    public static byte[] generateRandomIV() {
        SecureRandom secureRandom = new SecureRandom();
        byte[] iv = new byte[16]; // 128 bits
        secureRandom.nextBytes(iv);
        return iv;
    }
}
