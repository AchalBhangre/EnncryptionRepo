package com.example.Security.Algo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api")
public class MRIReportController {

    @Autowired
    private TwofishEncryptionService encryptionService;

    @PostMapping("/encrypt")
    public byte[] encryptReport(@RequestBody byte[] report) {
        return encryptionService.encrypt(report);
    }

    @PostMapping("/decrypt")
    public byte[] decryptReport(@RequestBody byte[] encryptedReport) {
        return encryptionService.decrypt(encryptedReport);
    }

    @PostMapping("/upload")
    public String handleFileUpload(@RequestParam("file") MultipartFile file) {
        // Implement your file upload and processing logic here
        if (!file.isEmpty()) {
            // Save the file or process it as needed
            // Example: File is not empty
        } else {
            // Handle empty file
            // Example: File is empty
        }

        // Redirect to a success page or return a response
        return "success";
    }
}

